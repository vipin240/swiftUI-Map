//
//  DetailedView.swift
//  SwiftUIMap
//
//  Created by Vipin Jain on 28/07/24.
//

import SwiftUI
import MapKit
struct DetailedView: View {
    @EnvironmentObject var vm : LocationViewModel
    let currentLocation : Location
    var body: some View {
        ScrollView{
            VStack{
                imageSection
                textSection
                    .padding(5)
                descriptionSection
                    .padding(5)
                mapSection
            }
            .overlay(alignment: .topLeading) {
                Button {
                    vm.sheetLocation = nil
                } label: {
                    Image(systemName: "xmark")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 25)
                        .padding(30)
                }

            }
        }
        .ignoresSafeArea(.all)
    }
}

#Preview {
    DetailedView(currentLocation: LocationsDataService.locations.first!)
        .environmentObject(LocationViewModel())
}
extension DetailedView {
    var imageSection : some View {
        TabView {
            let imageNames = currentLocation.imageNames
            ForEach(imageNames, id: \.self) {
                Image($0)
                    .resizable()
                    .scaledToFill()
                    .frame(width: UIScreen.main.bounds.width)
                    .clipped()
            }
        }
        .frame(height: 500)
        .tabViewStyle(.page)
        .ignoresSafeArea()
    }
    
    var textSection: some View {
        VStack(alignment: .leading){
            Text(currentLocation.name)
                .font(.title)
                .fontWeight(.bold)
            
            Text(currentLocation.cityName)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        
    }
    
    
    var descriptionSection : some View {
        VStack(alignment: .leading){
            Text(currentLocation.description)
                .font(.title3)
                .fontWeight(.light)
                .foregroundStyle(.secondary)
            let url = URL(string: currentLocation.link)
            Link("Wikipedia", destination: url!)
                .foregroundStyle(.blue)
                            
        }
    }
    
    var mapSection : some View {
        VStack{
            Map(coordinateRegion:  .constant(MKCoordinateRegion(center: currentLocation.coordinates,
                                                      span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))))
        }
        .frame(width: 380, height: 380)
        .clipShape(RoundedRectangle(cornerRadius: 30))
    }
}
