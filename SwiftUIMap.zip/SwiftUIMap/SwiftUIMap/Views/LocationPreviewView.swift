//
//  LocationPreviewView.swift
//  SwiftUIMap
//
//  Created by Vipin Jain on 28/07/24.
//

import SwiftUI
import MapKit

struct LocationPreviewView: View {
    @EnvironmentObject var vm: LocationViewModel
    var body: some View {
        HStack(alignment: .bottom){
            VStack(alignment: .leading){
                imageSection
                titleSection
            }
            ButtonView
        }
        .padding()
        .background(
        RoundedRectangle(cornerRadius: 10)
            .fill(.ultraThinMaterial)
            .offset(y: 65)
            .clipped()
        )
    }
}

#Preview {
    LocationPreviewView()
        .environmentObject(LocationViewModel())
}
extension LocationPreviewView {
    private var imageSection : some View {
        ZStack{
            if let imageName = vm.mapLocation.imageNames.first {
                Image(imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 100)
                    .cornerRadius(10)
                
            }
        }
    }
    private var titleSection : some View {
        VStack(alignment: .leading) {
            Text(vm.mapLocation.name)
                .font(.title2)
            Text(vm.mapLocation.cityName)
                .font(.title3)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    private var ButtonView : some View {
        VStack{
            Button(action: {
                vm.sheetLocation = vm.mapLocation
            }, label: {
                Text("Learn more")
                    .frame(width: 125,height: 40)
            })
            .buttonStyle(.borderedProminent)
            
            Button(action: {}, label: {
                Text("Next")
                    .frame(width: 125, height: 40)
            })
            .buttonStyle(.bordered)
        }
    }
}
