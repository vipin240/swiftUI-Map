//
//  ListUIView.swift
//  SwiftUIMap
//
//  Created by Vipin Jain on 28/07/24.
//

import SwiftUI
import MapKit

struct ListUIView: View {
    @EnvironmentObject private var vm : LocationViewModel
    var body: some View {
        List {
            ForEach(vm.locations){ location in
                RowUIView(location: location)
                
            }
        }
        .listStyle(.plain)
        
    }
}

struct RowUIView: View {
    @EnvironmentObject private var vm : LocationViewModel
    private var location : Location
    init(location : Location){
        self.location = location
    }
    var body : some View {
        HStack{
            if let imageName = location.imageNames.first {
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 50)
                    .cornerRadius(5)
            }
            
            VStack(alignment: .leading) {
                Text(location.name)
                    .font(.headline)
                
                Text(location.cityName)
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
        }
        .onTapGesture {
            vm.changeLocation(location: location)
        }
       
    }
}

#Preview {
    ListUIView()
        .environmentObject(LocationViewModel())
}
