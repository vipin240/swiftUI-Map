//
//  LocationView.swift
//  SwiftUIMap
//
//  Created by Vipin Jain on 21/07/24.
//

import SwiftUI
import MapKit


struct LocationsView: View {
    @EnvironmentObject private var vm : LocationViewModel
    
    var body: some View {
        ZStack{
            Map(coordinateRegion: $vm.mapRegion)
                .ignoresSafeArea()
            
            VStack{
              header
                    .padding()
                    .padding(.bottom, -30)
                if vm.showListView {
                    ListUIView()
                        .cornerRadius(10)
                        .padding()
                }
                
                
                Spacer()
                LocationPreviewView()
                    .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing), removal: .move(edge: .leading)))
                    .padding()
            }
        }
        .sheet(item: $vm.sheetLocation, onDismiss: nil) { location in
            DetailedView(currentLocation: location)
        }
    }
}

extension LocationsView {
   
    var header : some View {
            VStack {
                Text("\(vm.mapLocation.name), \(vm.mapLocation.cityName)")
                    .font(.title2)
                    .fontWeight(.black)
                    .foregroundColor(.primary)
                    .frame(height: 45)
                .frame(maxWidth: .infinity)
                .animation(.none, value: vm.mapLocation)
                .overlay(alignment: .leading) {
                    Image(systemName: "arrow.down")
                        .rotationEffect(Angle(degrees: vm.showListView ? 180 : 0))
                     
                        .padding()
                }
                
            }
            .onTapGesture(perform: {
                vm.toggleShowListView()
            }
             )
            .background(.thickMaterial)
            .cornerRadius(20)
            .shadow(color: .black.opacity(0.3), radius: 10, x: 0, y: 15)
    }
}

#Preview {
    LocationsView()
        .environmentObject(LocationViewModel())
}

