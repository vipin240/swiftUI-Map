//
//  LocationViewModel.swift
//  SwiftUIMap
//
//  Created by Vipin Jain on 21/07/24.
//

import Foundation
import SwiftUI
import MapKit

class LocationViewModel : ObservableObject {
 @Published var locations: [Location]
    @Published var mapLocation : Location
    {
        didSet{
            self.setMapRegon(mapLocation)
        }
    }
    @Published var mapRegion =  MKCoordinateRegion()
    @Published var showListView = false
    @Published var sheetLocation : Location? = nil
        init() {
            let locations = LocationsDataService.locations
            self.locations = locations
            self.mapLocation = locations.first!
            self.setMapRegon(locations.first!)
            
        }
    
    private func setMapRegon(_ location : Location){
        withAnimation(.easeInOut) {
            mapRegion = MKCoordinateRegion(center: location.coordinates,
                                           span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        }
       
    }
    func toggleShowListView() {
        withAnimation(.easeInOut){
            showListView.toggle()
        }
    }
    func changeLocation(location : Location) {
        mapLocation = location
        toggleShowListView()
    }
}
