//
//  SwiftUIMapApp.swift
//  SwiftUIMap
//
//  Created by Vipin Jain on 21/07/24.
//

import SwiftUI

@main
struct SwiftUIMapApp: App {
    @StateObject private var vm = LocationViewModel()
    var body: some Scene {
        WindowGroup {
            LocationsView()
                .environmentObject(vm)
        }
    }
}
